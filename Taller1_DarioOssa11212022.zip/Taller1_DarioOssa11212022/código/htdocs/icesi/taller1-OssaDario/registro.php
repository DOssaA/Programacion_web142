<!DOCTYPE html>
<html>
<head>
	<title>Taller1-Registro</title>
</head>
<body>

	<?php
		//para el feedback que puede llegar al llenar el formulario y enviarlo, puede ser que el 
		//usuario ya existe o que no se llenaron bien los datos
		if(isset($_GET['Message'])){
		    echo "<p style='color:red;'>".$_GET['Message']."</p>";
		}
	?>
	
	<h1><a href="home.php">Projector</a></h1>
	<br /><br /><br />
	
	<form action="includes/registrar_usuario.php" method="POST">
	 	<label>Usuario</label><input type="text" name="usuario" autocomplete="on" placeholder="nombre de usuario" /><br /> 
	 	<label>Clave</label><input type="password" name="contrasena" /><br /> 
	 	<label>Correo</label><input type="email" name="correo" autocomplete="on" /><br />
	 	<input type="submit" value="Registrar" />
	</form>
</body>
</html>