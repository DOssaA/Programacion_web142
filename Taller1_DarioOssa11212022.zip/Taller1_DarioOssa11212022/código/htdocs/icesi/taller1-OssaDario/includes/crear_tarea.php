<!-- Referencias: para la fecha de hoy -> http://stackoverflow.com/questions/470617/get-current-date-and-time-in-php  y  http://php.net/manual/en/timezones.america.php -->

<?php
	$nombre_tarea = $_POST["nombre_tarea"];
	$usuario = $_POST["usuario"];
	$fecha_lim = $_POST["fecha_lim"];
	$descripcion = $_POST["descripcion"];
	$prioridad = $_POST["prioridad"];

	//primero se revisa que todas las veriables recibidas por post existan y no estén vacias, si es así se revisa que el usuario dado
	//exista, si es asi se crea la tarea en la BD
	if (isset($nombre_tarea) && !empty($nombre_tarea) && isset($usuario) && !empty($usuario) && isset($fecha_lim) && !empty($fecha_lim) && isset($descripcion) && !empty($descripcion) && isset($prioridad) && !empty($prioridad)) {

		include_once("database.php");

		$queryS = "SELECT * FROM taller1_ossa_dario.usuarios WHERE (nombre_usuario='$usuario')";
		$resultS = mysqli_query($cxn,$queryS);
		$conteo = 0;	//conteo cuenta el número de registros

		while ($row = mysqli_fetch_array($resultS)) {
			$conteo ++;
		}

		if($conteo == 1){	//si el conteo es 1, hay un registro, entonces se procede a guardar en la base de datos
			date_default_timezone_set('America/Bogota');
			// $timezone = date_default_timezone_get();
			// echo "The current server timezone is: " . $timezone;
			$fecha_hoy = date('Y/d/m');

			$queryi = "SELECT * FROM taller1_ossa_dario.tareas_por_usuario ORDER BY id_tarea";
			$resulti = mysqli_query($cxn,$queryi);
			$ids = 0;	//para obtener la id última guardada en orden

			while ($row = mysqli_fetch_array($resulti)) {
				$ids = $row['id_tarea'];
			}

			$ids += 1;  //se aumenta en uno para los siguientes queries de guardado lo hagan al siguiente id

			//query para el llenado de la tabla de tareas con todos los datos
			$query = "INSERT INTO taller1_ossa_dario.tareas(`id_tarea`, `nombre_tarea`, `descripcion`, `prioridad`, `fecha_creacion`, `fecha_limite`) 
						VALUES ('$ids','$nombre_tarea','$descripcion','$prioridad','$fecha_hoy','$fecha_lim')";
			$result = mysqli_query($cxn,$query);
			
			//query para la tabla de tareas_por_usuario para indicar el usuario asignado a esa tarea
			$queryB = "INSERT INTO taller1_ossa_dario.tareas_por_usuario(`id_tarea`, `nombre_usuario`) VALUES ('$ids','$usuario')";
			$resultB = mysqli_query($cxn,$queryB);
			
			$Message = urlencode("Tarea creada satisfactoriamente");
			header("Location: ../home.php?Message=".$Message);
			die;
			
		}else{	//si no hay registros del usuario, entonces se devuelve el mensaje
			$Message = urlencode("El usuario escrito no existe");
			header("Location: ../crear_nueva_tarea.php?Message=".$Message);
			die;
		}
		
	}else{	//si hay datos que faltan o vacios se indica un mensaje
		$Message = urlencode("Por favor llena todos los datos para poder crear la tarea");
		header("Location: ../crear_nueva_tarea.php?Message=".$Message);
		die;
	}

?>