<?php
	//Se reciben los datos para asignar usuario enviados por método POST
	$id_tarea = $_POST["id_tarea"];
	$usuario = $_POST["usuario"];

	//si los datos dados no son vacios y existen, se revisan que el usuario dado exista, si es así se actualiza la base de datos
	if (isset($usuario) && !empty($usuario) && isset($id_tarea) && !empty($id_tarea)) {

		include_once("database.php");

		$queryS = "SELECT * FROM taller1_ossa_dario.usuarios WHERE (nombre_usuario='$usuario')";
		$resultS = mysqli_query($cxn,$queryS);
		$conteo = 0;

		while ($row = mysqli_fetch_array($resultS)) {
			$conteo ++;
		}

		if($conteo == 1){
			$query = "UPDATE taller1_ossa_dario.tareas_por_usuario SET nombre_usuario='$usuario' WHERE id_tarea='$id_tarea'";

			$result = mysqli_query($cxn,$query);
			
			$Message = urlencode("Cambio de usuario a ".$usuario." satisfactorio");
			header("Location: ../home.php?Message=".$Message."&id_tarea=".$id_tarea);
			die;
		}else{
			$Message = urlencode("El usuario a asignar no existe");
			header("Location: ../home.php?Message=".$Message);
			die;
		}
		
	}else{
		$Message = urlencode("Por favor escribe el nombre del nuevo usuario a asignar");
		header("Location: ../home.php?Message=".$Message);
		die;
	}

?>