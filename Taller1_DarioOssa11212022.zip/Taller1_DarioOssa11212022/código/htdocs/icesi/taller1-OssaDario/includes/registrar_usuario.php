<!-- Referencias: para pasar datos por header() -> http://stackoverflow.com/questions/12246102/php-passing-message-along-header-location -->

<?php
	//Se reciben los datos del registro enviados por método POST
	$usuario = $_POST["usuario"];
	$contrasena = $_POST["contrasena"];
	$correo = $_POST["correo"];


	//Se revisa primero que existan los datos dados y que no estén en blanco, si no están bien se devuelve al registro con un mensaje indicandolo
	//si si existen y no están en blanco, se revisa que el usuario exista o no antes, si existe, se devuelve al registro indicandolo, de lo contrario
	//ya si se procede a registrar el nuevo usuario y se redirige al index.php indicando que fue satisfactorio el registro
	if (isset($usuario) && !empty($usuario) && isset($contrasena) && !empty($contrasena) && isset($correo) && !empty($correo)) {

		include_once("database.php");

		$queryS = "SELECT * FROM taller1_ossa_dario.usuarios WHERE (nombre_usuario='$usuario')";
		$resultS = mysqli_query($cxn,$queryS);
		$conteo = 0;

		while ($row = mysqli_fetch_array($resultS)) {
			$conteo ++;
		}

		if($conteo == 1){
			$Message = urlencode("El usuario ya existe");
			header("Location: ../registro.php?Message=".$Message);
			die;
		}else{
			$query = "INSERT INTO taller1_ossa_dario.usuarios(`nombre_usuario`, `contrasena`, `correo`) VALUES ('$usuario','$contrasena','$correo')";

			$result = mysqli_query($cxn,$query);
			
			$Message = urlencode("Registro satisfactorio");
			header("Location: ../index.php?Message=".$Message);
			die;
		}
		
	}else{
		$Message = urlencode("Por favor llena los datos para poder realizar el registro");
		header("Location: ../registro.php?Message=".$Message);
		die;
	}

?>