
<!-- Referencias: para el inicio de sesión ->  http://web.tursos.com/como-hacer-un-sistema-de-login-de-usuarios-en-php-mysql/ -->

<?php
	session_start();  //para iniciar la grabación de datos temporales de sesión, en este caso para guardar el usuario al realizar login
	
	//función para verificar el nombre de usuario ingresado y la contraseña
	//retorna 1 si encuentra, 0 si no
	//el tercer parámetro que recibe lo llena con datos del usuario encontrado
	function verificarInicioSesion($usuario,$contrasena,&$result){
		include_once("includes/database.php");

		$query = "SELECT * FROM taller1_ossa_dario.usuarios WHERE (nombre_usuario='$usuario') AND (contrasena='$contrasena')";
		$res = mysqli_query($cxn,$query);
		$conteo = 0;

		while ($row = mysqli_fetch_array($res)) {
			$conteo ++;
			$result = $row;
		}
		if($conteo == 1){
			return 1;
		}else{
			return 0;
		}

	}

	if(!isset($_SESSION['user_id'])){   //si no existe un usuario en la sesión
		if(isset($_POST['Ingresar'])){		//si se ha hecho clic en el boton de hacer inicio de sesión (el botón tiene nombre ingresar)
			if(verificarInicioSesion($_POST['usuario'],$_POST['contrasena'],$result)==1){		//se verifica datos de inicio de sesión, y si el usuario existe
				$_SESSION['user_name'] = $result[nombre_usuario];		//se asigna datos y se redirige al home
				header("location:home.php");
			}else{
            	echo '<p>Su usuario o contrasena es incorrecto, intente de nuevo.</p>';		//de lo contrario feedback
        	}
		}
	

?>
<!DOCTYPE html>
<html lang="es">
<head>
	<title>Taller1-Inicio</title>
	<meta charset="utf-8">
</head>
<body>
	<h1>Projector</h1>
	<br />
	<br />
	<br />
	<!-- En este formulario al enviarse al oprimir el botón enviar, se envía por método POST a revisar_usuario.php para que allá se guarde el nuevo estudiante con los datos llenados  -->
	<form action="" method="POST"> <!-- action: el archivo al que se mandan los datos al hacer clic en submit -->
	 	<label></label><input type="text" name="usuario" autocomplete="on" placeholder="Nombre de usuario" /><br />  
	 	<label></label><input type="password" name="contrasena" autocomplete="on" placeholder="Clave" /><br />
	 	<input type="submit" name="Ingresar" value="Ingresar" />
	</form> 
	<?php
		}else{
			echo 'Su usuario ha ingresado correctamente.';
		}	

		echo "<br />";
		if(isset($_GET['Message'])){   //PARA LA CAPTURA DEL MENSAJE QUE PUEDE LLEGAR AL REALIZAR UN REGISTRO EXITOSO (desde registrar_usuario.php)
		    echo "<p style='color:green;'>".$_GET['Message']."</p>";
		}
	?>
	<br />
	<br />
	<br />
	<a href="registro.php">Registrarse</a>
	
</body>
</html>