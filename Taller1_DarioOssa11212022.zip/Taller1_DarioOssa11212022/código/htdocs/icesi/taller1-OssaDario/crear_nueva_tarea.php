<?php
	session_start();
	$usuario_login = "";
	if(isset($_SESSION['user_name'])){		//si hay usuario iniciado se asigna a la variable
		$usuario_login = $_SESSION['user_name'];
	}else{									//de lo contrario se redirige al index para iniciar sesión
		header("Location: index.php");
	}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<title>taller1-crear tarea nueva</title>
	<meta charset="utf-8">
</head>
<body>
	<?php
		if(isset($_GET['Message'])){
		    echo "<p'>".$_GET['Message']."</p>";
		}
	?>
	<table width="100%">
		<tr>
			<td>
				<h2><a href="home.php">Projector</a></h2>
			</td>
			<td>
				<h3> Usuario iniciado: <a href="perfil.php?usuario=<?php echo $usuario_login; ?>">
					<?php 
						echo $usuario_login; 
					?>
					</a>
				</h3>
				<p><a href="includes/logout.php">Cerrar sesión</a></p>
			</td>
		</tr>
		<tr>
			<td>
				<h3>Creando tarea nueva</h3>
				<form action="includes/crear_tarea.php" method="POST">
					<label>Prioridad</label><br /> 
					<input type="radio" name="prioridad" value="3" />Alta<br /> 
					<input type="radio" name="prioridad" value="2" />Media<br /> 
					<input type="radio" name="prioridad" value="1" />Baja<br /> 
					<label>Nombre tarea</label><input type="text" name="nombre_tarea" autocomplete="on" placeholder="nombre de la tarea" /><br /> 
					<label>Usuario asignado</label><input type="text" name="usuario" placeholder="quien debe realizarla" /><br /> 
				 	<label>Fecha limite</label><input type="text" name="fecha_lim" placeholder="aaaa-mm-dd" autocomplete="on" /><br />
				 	<!--!**!REVISAR SI FUNCIONA TEXTAREA PARA MANDAR LOS DATOS SIN ERROR!!**-->
				 	<label>Descripcion</label><textarea type="text" name="descripcion" placeholder="escribe en que consiste la tarea"></textarea><br /> 
				 	<br /> 
				 	<input type="submit" value="Crear" />
				</form>
			</td>
			<td>
				<br />
				<h3>Usuarios existentes</h3>
				<?php 
					include_once("includes/database.php");
					$queryB =  "SELECT nombre_usuario FROM taller1_ossa_dario.usuarios";
					$resultB = mysqli_query($cxn,$queryB);

					while($row = mysqli_fetch_array($resultB)){
						echo "<a href='perfil.php?usuario=".$row['nombre_usuario']."'>".$row['nombre_usuario']."</a>";
						echo "<br />";
					}
				?>
			</td>
		</tr>
	</table>	
</body>
</html>