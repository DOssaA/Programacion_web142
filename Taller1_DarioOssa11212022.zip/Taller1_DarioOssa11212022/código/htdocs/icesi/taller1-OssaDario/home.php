<?php
	session_start();
	$usuario_login = "";
	if(isset($_SESSION['user_name'])){		//si hay usuario iniciado se asigna a la variable
		$usuario_login = $_SESSION['user_name'];
	}else{									//de lo contrario se redirige al index para iniciar sesión
		header("Location: index.php");
	}
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<title>taller1-home</title>
	<meta charset="utf-8">
</head>
<body>
	<?php
		if(isset($_GET['Message'])){   //PARA LA CAPTURA DEL MENSAJE QUE PUEDE LLEGAR AL REALIZAR UNA ASIGNACIÖN DE TAREA (desde asignar_usuario.php)
		    echo "<p>".$_GET['Message']."</p>";
		}
	?>
	<table width="100%">
		<tr>
			<td>
				<h2><a href="home.php">Projector</a></h2>
			</td>
			<td>
				<h3> Usuario iniciado: <a href="perfil.php?usuario=<?php echo $usuario_login; ?>">
				<?php 
					echo $usuario_login; 
				?>
				</a></h3>
				<p><a href="includes/logout.php">Cerrar sesión</a></p>
			</td>
		</tr>
		<tr>
			<td>
				<br />
				<br />
				<h3>Tareas existentes</h3>
				<?php
					include_once("includes/database.php");
					$conteo = 0;
					$query =  "SELECT * FROM taller1_ossa_dario.tareas JOIN taller1_ossa_dario.tareas_por_usuario ON tareas.id_tarea = tareas_por_usuario.id_tarea";
					$result = mysqli_query($cxn,$query);

					while($row = mysqli_fetch_array($result)){ 
						echo "<form action='includes/asignar_usuario.php' method='POST'>";
						echo "  - <strong> Nombre tarea: ".$row["nombre_tarea"]."</strong>, para 
								<input type='text' name='usuario' placeholder='Nombre de usuario asignado' value='".$row["nombre_usuario"]."' />
								<input style='display: none;' name='id_tarea' value='".$row["id_tarea"]."' />
								<input type='submit' name='Cambiar' value='Cambiar' /></form>";
						$prioridad = $row["prioridad"];
						if($prioridad==3){
							echo "prioridad alta";
						}elseif ($prioridad==2) {
							echo "prioridad media";
						}elseif ($prioridad==1) {
							echo "prioridad baja";
						}
						echo " - ";
						echo "Creada en ".$row["fecha_creacion"]."    -     Fecha limite ".$row["fecha_limite"];
						echo "<br />";
						echo "<br />";
						echo " > ".$row["descripcion"];
						echo "<br />";
						echo "<br />";
						echo "<br />";
						echo "<br />";
						$conteo ++;
					}

					if($conteo==0){
						echo "(ninguna)";
					}

				?>
				<a href="crear_nueva_tarea.php">Crear nueva tarea</a>
				<br />
				<br />
			</td>
			<td>
				<br />
				<h3>Usuarios existentes</h3>
				<?php 
					include_once("includes/database.php");
					$queryB =  "SELECT nombre_usuario FROM taller1_ossa_dario.usuarios";
					$resultB = mysqli_query($cxn,$queryB);

					while($row = mysqli_fetch_array($resultB)){
						echo "<a href='perfil.php?usuario=".$row['nombre_usuario']."'>".$row['nombre_usuario']."</a>";
						echo "<br />";
					}
				?>
			</td>
		</tr>
	</table>
</body>
</html>