<?php
	session_start();
	$usuario_login = "";
	if(isset($_SESSION['user_name'])){		//si hay usuario iniciado se asigna a la variable
		$usuario_login = $_SESSION['user_name'];
	}else{									//de lo contrario se redirige al index para iniciar sesión
		header("Location: index.php");
	}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<title>taller1-perfil</title>
	<meta charset="utf-8">
</head>
<body>

	<?php
		if(isset($_GET['Message'])){
		    echo "<p'>".$_GET['Message']."</p>";
		}
	?>
	<table width="100%">
		<tr>
			<td>
				<h2><a href="home.php">Projector</a></h2>
			</td>
			<td>
				<h3> Usuario iniciado: <a href="perfil.php?usuario=<?php echo $usuario_login; ?>">
					<?php 
						echo $usuario_login; 
					?>
					</a>
				</h3>
				<p><a href="includes/logout.php">Cerrar sesión</a></p>
			</td>
		</tr>
		<tr>
			<td>
				<?php
					include_once("includes/database.php");
					$usuario = "";		
					$filtro = "";			
					if (isset($_GET["usuario"])){  //recepcion get usuario a poner datos de perfil
						$usuario = $_GET["usuario"];
					}
					if(isset($_GET["filtro"])){   //recepcion get filtros
						$filtro = $_GET["filtro"];		
					}
					$query = "SELECT correo FROM taller1_ossa_dario.usuarios WHERE nombre_usuario='$usuario' ";
					$result = mysqli_query($cxn,$query); 
					$correo = "";
					while($row = mysqli_fetch_array($result)){
						$correo = $row['correo'];
					}
					echo "<h2>$usuario"." - "."$correo</h2>";
					echo "<h3>Tareas asignadas</h3>";
					?>

					Filtrar por:
					<a href="perfil.php?usuario=<?php echo $usuario ?>&filtro=fecha">Fecha</a>
					<a href="perfil.php?usuario=<?php echo $usuario ?>&filtro=prioridad">Prioridad</a>
					<br />
					<br />

					<?php

					$conteo = 0;
					$queryB = "SELECT * FROM taller1_ossa_dario.tareas JOIN taller1_ossa_dario.tareas_por_usuario ON tareas.id_tarea = tareas_por_usuario.id_tarea WHERE nombre_usuario='$usuario' ";
					if(!empty($filtro)){
						if($filtro == "fecha"){
							$queryB .= "ORDER BY fecha_limite DESC";
						}
						if($filtro == "prioridad"){
							$queryB .= "ORDER BY prioridad DESC";
						}
					}

					$resultB = mysqli_query($cxn,$queryB);

					while($row = mysqli_fetch_array($resultB)){ 
						echo "<form action='includes/asignar_usuario.php' method='POST'>";
						echo "  - <strong> Nombre tarea: ".$row["nombre_tarea"]."</strong>, para 
								<input type='text' name='usuario' placeholder='Nombre de usuario asignado' value='".$row["nombre_usuario"]."' />
								<input style='display: none;' name='id_tarea' value='".$row["id_tarea"]."' />
								<input type='submit' name='Cambiar' value='Cambiar' /></form>";
						$prioridad = $row["prioridad"];
						if($prioridad==3){
							echo "prioridad alta";
						}elseif ($prioridad==2) {
							echo "prioridad media";
						}elseif ($prioridad==1) {
							echo "prioridad baja";
						}
						echo " - ";
						echo "Creada en ".$row["fecha_creacion"]."    -     Fecha limite ".$row["fecha_limite"];
						echo "<br />";
						echo "<br />";
						echo " > ".$row["descripcion"];
						echo "<br />";
						echo "<br />";
						echo "<br />";
						$conteo ++;
					}

					if($conteo==0){
						echo "(ninguna)";
					}

				?>
				<a href="crear_nueva_tarea.php">Crear nueva tarea</a>
			</td>
		</tr>
	</table>
</body>
</html>