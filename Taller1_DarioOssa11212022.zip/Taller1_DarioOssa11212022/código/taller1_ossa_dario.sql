-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-09-2014 a las 06:53:14
-- Versión del servidor: 5.6.16
-- Versión de PHP: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `taller1_ossa_dario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tareas`
--

CREATE TABLE IF NOT EXISTS `tareas` (
  `id_tarea` int(254) NOT NULL AUTO_INCREMENT,
  `nombre_tarea` varchar(766) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(766) COLLATE utf8_bin NOT NULL,
  `prioridad` int(4) NOT NULL COMMENT '1, baja, 2, media, 3, alta',
  `fecha_creacion` date NOT NULL,
  `fecha_limite` date NOT NULL,
  PRIMARY KEY (`id_tarea`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `tareas`
--

INSERT INTO `tareas` (`id_tarea`, `nombre_tarea`, `descripcion`, `prioridad`, `fecha_creacion`, `fecha_limite`) VALUES
(1, 'Tarea web', 'Realizar la tarea viendo requerimientos github thimael', 2, '2014-10-07', '2014-10-10'),
(2, 'Nueva', 'descripcion de prueba', 3, '2014-10-09', '2014-10-11'),
(3, 'Lorem', 'Ipsum', 1, '2014-10-09', '2014-10-12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tareas_por_usuario`
--

CREATE TABLE IF NOT EXISTS `tareas_por_usuario` (
  `id_tarea` int(254) NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(766) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id_tarea`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=9 ;

--
-- Volcado de datos para la tabla `tareas_por_usuario`
--

INSERT INTO `tareas_por_usuario` (`id_tarea`, `nombre_usuario`) VALUES
(1, 'Usuario1'),
(2, 'Nuevo'),
(3, 'Nuevo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `nombre_usuario` varchar(766) COLLATE utf8_bin NOT NULL,
  `contrasena` varchar(766) COLLATE utf8_bin NOT NULL,
  `correo` varchar(766) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`nombre_usuario`, `contrasena`, `correo`) VALUES
('Usuario1', '12345', 'usuario1@mail.com'),
('Nuevo', '12345', 'mail@mail.com'),
('Dario', '1234', 'dario.ossa.a@gmail.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
