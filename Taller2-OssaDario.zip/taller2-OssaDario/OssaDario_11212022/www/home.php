<?php
	session_start();
	if(!(isset($_SESSION['user_id']))){		//si no hay usuario iniciado 
		header("Location: index.php");    //al index para iniciar sesión
	}
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Taller2</title>
	<link rel="stylesheet" href="css/styles.css">
</head>
<body>
	<header id="ElHeader">
		<!--figure><img src="logo.png" alt="" /></figure-->
		<div class="containHeader">
			<h1><a href="home.php">Tech Commercer</a></h1>
			<nav>
				<ul>
					<li><a href="perfil.php">Mi cuenta</a></li>
					<li><a href="catalogo.php">Catálogo</a></li>
					<li><a href="logout.php">Salir</a></li>
				</ul>
			</nav>
			<div id="barra_busqueda">
				<form action="">	
					<input type="text" name="busqueda" placeholder="Estoy buscando..." />
					<!--button id="btn_busqueda" type="submit" name="ico" /-->
					<div id="btn_busqueda">
						<a href="#"><figure><img src="img/btn_busqueda.png"/></figure></a>
					</div>
				</form>
			</div>
		</div>
	</header>
	<div id="contenedor">  <!-- contenedor del contenido de la página -->
		<section>
			<div class="titulo_seccion">
				<figure id="ico"><img src="img/Ic_home.png" alt=""></figure>
				<h1>Productos destacados del día</h1>
				<div id="link_carrito">
					<a href="carrito.php"><figure><img src="img/Ic_carrito.png" alt=""></figure></a>   <!-- Link al carrito, único en el home y catalogo -->
				</div>
			</div>

		<?php
			include_once("includes/database.php");
				

			$query = "SELECT * FROM taller2_ossa_dario.productos";   //php lee todo el quey antes de ejecutarlo, por lo que entiende las asignaciones que se le dan
																								// asì sea que se use antes o despues de definir a que se refiere (en el AS)

			$queryParaSiDestacado = "SELECT * FROM taller2_ossa_dario.puntos";

			$result = mysqli_query($cxn, $query);
			$resultQPD = mysqli_query($cxn, $queryParaSiDestacado);
			
			while ($row = mysqli_fetch_array($result)) {

				// en esta parte se mira si el producto ha sido destacado por algun usuario, si es asi se permite poner el producto y sus datos como destacado
				$productoDestacado = false;

				while ($rowQPD = mysqli_fetch_array($resultQPD)) {
					if($row['id'] == $rowQPD['id_producto']){
						$productoDestacado = true;
						break;
					}
				}
				$resultQPD = mysqli_query($cxn, $queryParaSiDestacado);   //se vuelve a hacer la petición de resultados de si el producto es destacado para el siguiente producto saber si cumple o no

				if($productoDestacado == true){
					// datos puntaje del producto
					//se mira si el producto ha sido destacado por el usuario
					$puntos_user = 0;
					$queryPts =  "SELECT count(*) AS numPuntos FROM taller2_ossa_dario.puntos WHERE id_producto='".$row["id"]."' AND id_usuario='".$_SESSION['user_id']."'";  
					$resQPts = mysqli_query($cxn, $queryPts);
					while($rowPts = mysqli_fetch_array($resQPts)){
						$puntos_user +=  $rowPts['numPuntos'];
					}
					
					//se mira si producto está en el carrito
					$en_el_carrito = 0;
					$queryPEC = "SELECT count(*) AS numCarrito FROM taller2_ossa_dario.prods_en_el_carrito WHERE id_usuario='".$_SESSION['user_id']."' AND id_producto='".$row["id"]."'";
					$resPEC = mysqli_query($cxn, $queryPEC);
					while($rowPEC = mysqli_fetch_array($resPEC)){
						$en_el_carrito = $rowPEC ['numCarrito'];
					}

					//print_r($resQPts);

					//articulos
					echo '<article class="article_producto">';
						echo '<div class="contenedor_imagen_home">';
							echo '<figure class="imagen_prod"><img src="'.$row['imagen'].'" alt=""></figure>';
							echo '<div class="contenedor_icono_compra">';
								if($en_el_carrito == 0) {
									echo '<a href="toggle_carrito.php?id_producto='.$row["id"].'&to=home"><figure><img src="img/no_anadido_carrito.png" alt=""></figure></a>';
								} else {
									echo '<a href="toggle_carrito.php?id_producto='.$row["id"].'&to=home"><figure class="carrito"><img src="img/anadido_carrito.png" alt=""></figure></a>';
								}
							echo '</div>';
						echo '</div>';
						
						echo '<div class="datos_prod">';

							echo '<h1>'.$row['nombre'].'</h1>';
							echo '<p class="precio">$'.$row['precio'].'</p>';
								if($puntos_user == 0) {
									echo '<a href="toggle_puntos.php?id_producto='.$row["id"].'&to=home"><figure><img src="img/calif_o.png" alt=""></figure></a>';  //imagen de que otro lo destacó
								} else {
									echo '<a href="toggle_puntos.php?id_producto='.$row["id"].'&to=home"><figure><img src="img/calif_u.png" alt=""></figure></a>';  //imagen de que fue destacado por el que ha iniciado sesión
								}
						echo "</div>";

					echo '</article>';
				}

				

			}
		?>
		<a href="#">
			<figure id="siguientes_destac"><img src="img/flecha_der.png" alt=""></figure>
		</a>
		</section>
		<br />
	</div>	
	<footer>
		<p><a href="#">Condiciones y políticas</a></p>
		<p>© Tech Commercer Inc. 2014</p>
	</footer>
</body>
</html>