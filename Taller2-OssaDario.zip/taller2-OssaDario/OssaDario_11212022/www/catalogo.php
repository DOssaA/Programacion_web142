
<!-- Catalogo -->

<?php
	session_start();
	if(!(isset($_SESSION['user_id']))){		//si no hay usuario iniciado 
		header("Location: index.php");    //al index para iniciar sesión
	}
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Taller2</title>
	<link rel="stylesheet" href="css/styles.css">
</head>
<body>	
	<header id="ElHeader">
		<!--figure><img src="logo.png" alt="" /></figure-->
		<div class="containHeader">
			<h1><a href="home.php">Tech Commercer</a></h1>
			<nav>
				<ul>
					<li><a href="perfil.php">Mi cuenta</a></li>
					<li><a href="catalogo.php">Catálogo</a></li>
					<li><a href="includes/logout.php">Salir</a></li>
				</ul>
			</nav>
			<div id="barra_busqueda">
				<form action="">	
					<input type="text" name="busqueda" placeholder="Estoy buscando..." />
					<!--button id="btn_busqueda" type="submit" name="ico" /-->
					<div id="btn_busqueda">
						<a href="#"><figure><img src="img/btn_busqueda.png"/></figure></a>
					</div>
				</form>
			</div>
		</div>
	</header>
	<div id="contenedor">  <!-- contenedor del contenido de la página -->
		<section>
			<div class="titulo_seccion">
				<figure id="ico"><img src="img/Ic_catalogo.png" alt=""></figure>
				<h1>Todo lo que te ofrecemos</h1>
				<div id="link_carrito">
					<a href="carrito.php"><figure><img src="img/Ic_carrito.png" alt=""></figure></a>   <!-- Link al carrito, único en el home y catalogo -->
				</div>
			</div>

			<?php
			include_once("includes/database.php");
				

			$query = "SELECT * FROM taller2_ossa_dario.productos";   //php lee todo el quey antes de ejecutarlo, por lo que entiende las asignaciones que se le dan
																								// asì sea que se use antes o despues de definir a que se refiere (en el AS)

			$result = mysqli_query($cxn, $query);
			
			while ($row = mysqli_fetch_array($result)) {

				// datos puntaje del producto
				$total_puntos = 0;   //total destaques DEBE SER AL MENOS UNA VEZ DESTACADO POR UN USUARIO PARA ESTAR COMO PRODUCTO DESTACADO
				$queryPts =  "SELECT count(*) AS numPuntos FROM taller2_ossa_dario.puntos WHERE id_producto='".$row["id"]."'";    //!!!!!****!!!!!!** FALTA PONER ESTO EN EL DIRECTORIO DE QUERIES !!!!******!!!!!*//******!!!!!**********!!!!!!*****!!!!!!
				$resQPts = mysqli_query($cxn, $queryPts);
				while($rowPts = mysqli_fetch_array($resQPts)){
					$total_puntos +=  $rowPts['numPuntos'];
				}
				
				//se mira si producto está en el carrito
				$en_el_carrito = 0;
				$queryPEC = "SELECT count(*) AS numCarrito FROM prods_en_el_carrito WHERE id_usuario='".$_SESSION['user_id']."'";
				$resPEC = mysqli_query($cxn, $queryPEC);
				while($rowPEC = mysqli_fetch_array($resQPts)){
					$en_el_carrito = $rowPEC ['numCarrito'];
				}


				//print_r($resQPts);

				echo '<article class="article_producto catalogo" >';
					echo '<div class="contenedor_imagen_home">';
						echo '<figure><img src="'.$row['imagen'].'" alt=""></figure>';
						echo '<div class="contenedor_icono_compra">';
							if($en_el_carrito == 0) {
							echo '<a href="includes/toggle_carrito.php?id_producto='.$row["id"].'&to_value=1"><figure><img src="img/no_anadido_carrito.png" alt=""></figure></a>';
							} else {
								echo '<a href="includes/toggle_carrito.php?id_producto='.$row["id"].'&to_value=0"><figure class="carrito"><img src="img/anadido_carrito.png" alt=""></figure></a>';
							}
						echo '</div>';
					echo '</div>';
					echo '<div class="datos_prod">';

						echo '<h1>'.$row['nombre'].'</h1>';
						echo '<p class="precio">$'.$row['precio'].'</p>';

						
							echo '<a href="toggle_puntos_user.php?id_producto='.$row["id"].'"><figure><img src="" alt=""></figure></a>';
					echo "</div>";

				echo '</article>';

			}
		?>
		<div id="bajar">
			<a href="#"><figure><img src="img/flecha_abajo.png		" alt=""></figure></a>
		</div>
		</section>
	</div>	
	<footer>
		<p><a href="#">Condiciones y políticas</a></p>
		<p>© Tech Commercer Inc. 2014</p>
	</footer>
</body>
</html>
