<!-- Referencias: para la fecha de hoy -> http://stackoverflow.com/questions/470617/get-current-date-and-time-in-php  y  http://php.net/manual/en/timezones.america.php -->

<?php
	session_start();

	include_once("includes/database.php");

	$usuario = $_SESSION["user_id"];
	$id_productos = $_SESSION["productos_comprar"];  //llega un arraylist de productos en el carrito, por eso se recorre en un for abajo
	$prods_en_el_carrito = 0;

	for ($i=0; $i < sizeof($id_productos); $i++) { 


		date_default_timezone_set('America/Bogota');
		// $timezone = date_default_timezone_get();
		// echo "The current server timezone is: " . $timezone;
		$fecha_hoy = date('Y/m/d');
		echo $id_productos[$i];
		$query = "INSERT INTO taller2_ossa_dario.prods_comprados(`id`, `id_usuario`, `id_producto`, `fecha_compra`) VALUES ('','$usuario','$id_productos[$i]','$fecha_hoy')";
		$result = mysqli_query($cxn,$query);
	}

	
	$Message = urlencode("Producto(s) comprados satisfactoriamente");
	header("Location: perfil.php?Message=".$Message);
	die;
?>