
<!-- Referencias: para el inicio de sesión ->  http://web.tursos.com/como-hacer-un-sistema-de-login-de-usuarios-en-php-mysql/ -->
    
<?php
	session_start();

	if(isset($_SESSION['user_id'])){   //si ya hay sesión iniciada se dirige al home
		header("Location: home.php");
	}

	function verificarInicioSesion($usuario,$contrasena,&$result){
		include_once("includes/database.php");

		$query = "SELECT * FROM taller2_ossa_dario.usuarios WHERE (usuario='$usuario') AND (contrasena='$contrasena')";         //!!!***!!REVISAR QUERY Y código PHP!!!!*****!!!!!****!!!!*****!!!!!!!!
		$res = mysqli_query($cxn,$query);
		$conteo = 0;

		while ($row = mysqli_fetch_array($res)) {
			$conteo ++;
			$result = $row;
		}
		if($conteo == 1){
			return 1;
		}else{
			return 0;
		}
	}
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<title>Taller2</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/styles.css">
</head>
<body>
	<section id="delIndex">
		<br />
		<article id="arti_index">
			<header>
				<h1>Tech Commercer</h1>  
				<h2 id="tex_inicio_sesion">Inicia sesión</h1>
			</header>
			<form action="" method="POST">
			 	<label>Usuario</label><br /><input type="text" name="usuario" autocomplete="on"/><br />  
			 	<label>Contraseña</label><br /><input type="password" name="contrasena" autocomplete="on" /><br />
			 	<a id="recordar_contras" href="#">Olvidé mi contraseña</a><br />
			 	<input class="boton" type="submit" name="Ingresar" value="Iniciar sesión" />
			 	<input class="boton" type="submit" name="Registrar" value="Soy un nuevo cliente" />
			 	<div class="recordacion">
			 		<p>Al acceder aceptas nuestras <br /><a href="#">Políticas</a> sobre el uso de la información</p>
			 	</div>	
			 	<?php  				
						
				if(!isset($_SESSION['user_id'])){   //si no existe un usuario en la sesión
					if(isset($_POST['Registrar'])){		// si se hace clic en registrarse
						header("location:registro.php");	//se dirige al registro
					}
					if(isset($_POST['Ingresar'])){
						//si se ha hecho clic en el boton de hacer inicio de sesión (el botón tiene nombre ingresar)
						if(verificarInicioSesion($_POST['usuario'],$_POST['contrasena'],$result)==1){		//se verifica datos de inicio de sesión, y si el usuario existe
							$_SESSION['user_name'] = $result['usuario'];		//se asigna datos y se redirige al home
							$_SESSION['user_id'] = $result['id'];
							header("location:home.php");
						}else{
						    echo '<p style="background:orange; margin-bottom:10px;">Su usuario o contrasena es incorrecto, intente de nuevo.</p>';		//feedback
						    echo '<br />';
						}
					}
				}
				echo "<br />";
				if(isset($_GET['Message'])){   //PARA LA CAPTURA DEL MENSAJE QUE PUEDE LLEGAR AL REALIZAR UN REGISTRO EXITOSO (desde registrar_usuario.php)
				    echo "<p style='color:green;'>".$_GET['Message']."</p>";
				}
				?>
			</form> 
			<!--
			<div id="Registrarse"><a href="registro.php">Soy un nuevo cliente</a></div>   ver si esto funciona asi o como pues no se si se puede poner en el formulario de arriba sin enviar datos 
			-->
		</article>
	</section>
	
	<footer> 
		<p><a href="#">Condiciones y políticas</a></p>
		<p>© Tech Commercer Inc. 2014</p>
	</footer>
	
	<br />
	<br />
	<br />
	
	
</body>
</html>