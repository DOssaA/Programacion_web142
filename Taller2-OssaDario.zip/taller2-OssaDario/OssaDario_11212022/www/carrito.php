<?php
	session_start();
	if(!(isset($_SESSION['user_id']))){		//si no hay usuario iniciado 
		header("Location: index.php");    //al index para iniciar sesión
	}
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Taller2</title>
	<link rel="stylesheet" href="css/styles.css">
</head>
<body>	
	<header id="ElHeader">
		<!--figure><img src="logo.png" alt="" /></figure-->
		<div class="containHeader">
			<h1><a href="home.php">Tech Commercer</a></h1>
			<nav>
				<ul>
					<li><a href="perfil.php">Mi cuenta</a></li>
					<li><a href="catalogo.php">Catálogo</a></li>
					<li><a href="includes/logout.php">Salir</a></li>
				</ul>
			</nav>
			<div id="barra_busqueda">
				<form action="">	
					<input type="text" name="busqueda" placeholder="Estoy buscando..." />
					<!--button id="btn_busqueda" type="submit" name="ico" /-->
					<div id="btn_busqueda">
						<a href="#"><figure><img src="img/btn_busqueda.png"/></figure></a>
					</div>
				</form>
			</div>
		</div>
	</header>
	<div id="contenedor">  <!-- contenedor del contenido de la página -->
		<section>
			<div class="titulo_seccion">
				<figure id="ico"><img src="img/Ic_carrito.png" alt=""></figure>
				<h1>Mi Carrito</h1>
			</div>

			<?php
			include_once("includes/database.php");
				

			$query = "SELECT * FROM taller2_ossa_dario.productos AS p JOIN taller2_ossa_dario.prods_en_el_carrito AS penc ON (p.id = penc.id_producto) WHERE penc.id_usuario='".$_SESSION['user_id']."'";   //php lee todo el quey antes de ejecutarlo, por lo que entiende las asignaciones que se le dan
																								// asì sea que se use antes o despues de definir a que se refiere (en el AS)

			$result = mysqli_query($cxn, $query);
			
			while ($row = mysqli_fetch_array($result)) {

				echo '<article class="article_producto">';
					echo '<div class="contenedor_imagen_home">';
						echo '<figure><img src="'.$row['imagen'].'" alt=""></figure>';
					echo '</div>';
					echo '<div class="datos_prod">';
						echo '<h1>'.$row['nombre'].'</h1>';
						echo '<p class="precio">$'.$row['precio'].'</p>';
					echo "</div>";

				echo '</article>';

			}
		?>
		<p>Subtotal:</p>
		<button name="comprar">Efectuar la compra</button>
		</section>
	</div>	
	<footer>
		<p><a href="#">Condiciones y políticas</a></p>
		<p>© Tech Commercer Inc. 2014</p>
	</footer>
</body>
</html>