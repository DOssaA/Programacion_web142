
<!-- Referencias paso de datos de un array por serializacion: http://stackoverflow.com/questions/14071587/php-pass-array-through-post -->

<?php
	session_start();
	if(!(isset($_SESSION['user_id']))){		//si no hay usuario iniciado 
		header("Location: index.php");    //al index para iniciar sesión
	}
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Taller2</title>
	<link rel="stylesheet" href="css/styles.css">
</head>
<body>	
	<header id="ElHeader">
		<!--figure><img src="logo.png" alt="" /></figure-->
		<div class="containHeader">
			<h1><a href="home.php">Tech Commercer</a></h1>
			<nav>
				<ul>
					<li><a href="perfil.php">Mi cuenta</a></li>
					<li><a href="catalogo.php">Catálogo</a></li>
					<li><a href="logout.php">Salir</a></li>
				</ul>
			</nav>
			<div id="barra_busqueda">
				<form action="">	
					<input type="text" name="busqueda" placeholder="Estoy buscando..." />
					<!--button id="btn_busqueda" type="submit" name="ico" /-->
					<div id="btn_busqueda">
						<a href="#"><figure><img src="img/btn_busqueda.png"/></figure></a>
					</div>
				</form>
			</div>
		</div>
	</header>
	<div id="contenedor">  <!-- contenedor del contenido de la página -->
		<section>
			<div class="titulo_seccion">
				<figure id="ico"><img src="img/Ic_carrito.png" alt=""></figure>
				<h1>Mi Carrito</h1>
			</div>

			<?php
			include_once("includes/database.php");
				

			$query = "SELECT * FROM taller2_ossa_dario.productos AS p JOIN taller2_ossa_dario.prods_en_el_carrito AS penc ON (p.id = penc.id_producto) WHERE penc.id_usuario='".$_SESSION['user_id']."'";   

			$result = mysqli_query($cxn, $query);

			$subtotal = 0;
			$unidades_en_carrito = 0;

			$productos_a_comprar =[];
			
			while ($row = mysqli_fetch_array($result)) {

				array_push($productos_a_comprar, $row['id_producto']);   //se vam acumulamdo los productos en el carrito para al comprar comprarlos todos

				echo '<article class="article_carrito">';
					echo '<div class="contenedor_imagen_home">';
						echo '<figure class="imagen_prod"><img src="'.$row['imagen'].'" alt=""></figure>';
					echo '</div>';
					echo '<div class="datos_prod">';
						echo '<h1>'.$row['nombre'].'</h1>';
						echo '<p class="precio">$'.$row['precio'].'</p>';
					echo "</div>";

				echo '</article>';

				$subtotal += $row['precio'];
				$unidades_en_carrito ++;

			}

			$_SESSION['productos_comprar'] = $productos_a_comprar;
			?>
			<p id="subtotal_carrito">Subtotal: <span class="precio">$<?php echo $subtotal; ?></span> <span>(<?php echo $unidades_en_carrito; ?> unidades)</span></p>
			<div class="btn_comprar">	
				<a class="button-link" href="comprar.php">Efectuar la compra</a>
			</div>
		</section>
	</div>	
	<footer>
		<p><a href="#">Condiciones y políticas</a></p>
		<p>© Tech Commercer Inc. 2014</p>
	</footer>
</body>
</html>