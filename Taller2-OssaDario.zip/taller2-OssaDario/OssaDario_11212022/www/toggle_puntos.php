<?php    //esta página serviría para poner o quitar puntos de un usuario en la base de datos
	session_start();

	include_once("includes/database.php");

	$usuario = $_SESSION["user_id"];
	$id_producto = $_GET["id_producto"];

	$puntos_user = 0;

	$queryA = "SELECT count(*) AS num_puntos FROM taller2_ossa_dario.puntos WHERE id_producto='$id_producto' AND id_usuario='$usuario'"; 
	$result = mysqli_query($cxn, $queryA);

	while($rowD = mysqli_fetch_array($result)){
		$puntos_user = $rowD["num_puntos"];
	}

	if($puntos_user == 0){
		$queryCambiar = "INSERT INTO taller2_ossa_dario.puntos(`id`, `id_usuario`, `id_producto`) VALUES ('','$usuario','$id_producto')";
	}else{
		$queryCambiar = "DELETE FROM taller2_ossa_dario.puntos WHERE id_usuario='$usuario' AND id_producto = '$id_producto'";
	}
	$rNumprods_en_el_carrito = mysqli_query($cxn, $queryCambiar);

	header("Location: ".$_GET["to"].".php");  //'to' era el indicador de de donde provenía y por tanto a donde debe regresar
	die;
?>