<?php
	session_start();

	include_once("database.php");

	$usuario = $_SESSION["id_iniciado"];
	$id_producto = $_GET["id_producto"];
	$prods_en_el_carrito = 0;


	$queryA = "SELECT count(*) AS numprods_en_el_carrito FROM taller2_ossa_dario.prods_en_el_carrito WHERE id_producto='$id_producto' AND id_usuario='$usuario'"; 
	$rNumprods_en_el_carritoUser = mysqli_query($cxn, $queryA);

	echo $prods_en_el_carrito;

	while($rowD = mysqli_fetch_array($rNumprods_en_el_carritoUser)){
		$prods_en_el_carrito = $rowD["numprods_en_el_carrito"];
	}

	echo $prods_en_el_carrito;

	if($prods_en_el_carrito == 0){
		$queryCambiarprods_en_el_carrito = "INSERT INTO taller2_ossa_dario.prods_en_el_carrito(`id`, `id_usuario`, `id_producto`) VALUES ('','$usuario','$id_producto')";
	}else{
		$queryCambiarprods_en_el_carrito = "DELETE FROM taller2_ossa_dario.prods_en_el_carrito WHERE id_usuario='$usuario' AND id_producto = '$id_producto'";
	}

	// $queryNumFavs = "SELECT count(*) AS numFavs FROM ejercicio_pag_mensajes.prods_en_el_carrito WHERE id_producto='".$row["id_producto"]."'";   //un query siempre devuelve un objeto Object, un registro, en este caso en el campo num
	$rNumprods_en_el_carrito = mysqli_query($cxn, $queryCambiarprods_en_el_carrito);

	header("Location: ../home.php");
?>