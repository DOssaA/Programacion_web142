<?php    //esta página serviría para poner o quitar productos del carrito de un usuario en la base de datos
	session_start();

	include_once("includes/database.php");

	$usuario = $_SESSION["user_id"];
	$id_producto = $_GET["id_producto"];
	$prods_en_el_carrito = 0;

	echo $id_producto;

	$queryA = "SELECT count(*) AS numprods_en_el_carrito FROM taller2_ossa_dario.prods_en_el_carrito WHERE id_producto='$id_producto' AND id_usuario='$usuario'"; 
	$rNumprods_en_el_carritoUser = mysqli_query($cxn, $queryA);

	echo $prods_en_el_carrito;

	while($rowD = mysqli_fetch_array($rNumprods_en_el_carritoUser)){
		$prods_en_el_carrito = $rowD["numprods_en_el_carrito"];
	}

	echo $prods_en_el_carrito;

	if($prods_en_el_carrito == 0){
		$queryCambiarprods_en_el_carrito = "INSERT INTO taller2_ossa_dario.prods_en_el_carrito(`id`, `id_usuario`, `id_producto`) VALUES ('','$usuario','$id_producto')";
	}else{
		$queryCambiarprods_en_el_carrito = "DELETE FROM taller2_ossa_dario.prods_en_el_carrito WHERE id_usuario='$usuario' AND id_producto = '$id_producto'";
	}

	$rNumprods_en_el_carrito = mysqli_query($cxn, $queryCambiarprods_en_el_carrito);

	header("Location: ".$_GET["to"].".php");  //'to' era el indicador de de donde provenía y por tanto a donde debe regresar
	die;
?>