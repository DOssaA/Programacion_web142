-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-10-2014 a las 20:39:40
-- Versión del servidor: 5.6.16
-- Versión de PHP: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `taller2_ossa_dario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prods_comprados`
--

CREATE TABLE IF NOT EXISTS `prods_comprados` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(255) NOT NULL,
  `id_producto` int(255) NOT NULL,
  `fecha_compra` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `prods_comprados`
--

INSERT INTO `prods_comprados` (`id`, `id_usuario`, `id_producto`, `fecha_compra`) VALUES
(1, 1, 1, '2014-10-16');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prods_en_el_carrito`
--

CREATE TABLE IF NOT EXISTS `prods_en_el_carrito` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(255) NOT NULL,
  `id_producto` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `prods_en_el_carrito`
--

INSERT INTO `prods_en_el_carrito` (`id`, `id_usuario`, `id_producto`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(766) COLLATE utf8_bin NOT NULL,
  `imagen` varchar(766) COLLATE utf8_bin NOT NULL,
  `precio` float NOT NULL,
  `especificaciones` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `imagen`, `precio`, `especificaciones`) VALUES
(1, 'Samsung Galaxy Gear, Android Smart Watch Para S3, S4, Note 2 y 3', 'img/sg1.JPG', 129998, 'Estado: 	\r\nReacondicionado por el vendedor\r\n	Marca: 	\r\nSamsung\r\nCamera Resolution: 	\r\n1.9MP\r\n	MPN: 	\r\nSM-V700\r\nSpeaker: 	\r\nMono\r\n	Compatible Operating System: 	\r\nAndroid\r\nSensors: 	\r\nAccelerometer, Gyroscope\r\n	Processor: 	\r\n800MHz Single-Core Processor\r\nBluetooth Compliant: 	\r\n4.0\r\n	Capacidad de disco duro: 	\r\n4 GB\r\nTipo de batería: 	\r\nLiION\r\n	RAM: 	\r\n512 MB\r\nBattery Capacity: 	\r\n315 mAh\r\n	Display Size (Diagonal): 	\r\n1.63 Inches\r\nCompatibilty: 	\r\nGalaxy S III, S4, Note II, Note 3\r\n	Screen Resolution: 	\r\n320 x 320'),
(2, 'Beats By Dre Studio de alta definición de cancelación de ruido más de Oreja Monster Auriculares', 'img/dre.JPG', 15000, 'Estado: 	\r\nNuevo: Un artículo totalmente nuevo, sin usar, sin abrir y sin daños, en su envase original (en los casos ... Más informaciónsobre el estado	\r\n	Diseño del auricular: 	\r\nDiseño de cúpula (cubre la oreja)\r\nConectividad: 	\r\nCon cable\r\n	Diseño ajustado: 	\r\nDe diadema\r\nCaracterísticas: 	\r\nIn-Line Control & Mic\r\n	Marca: 	\r\nBeats by Dr. Dre\r\nArtículos en paquete: 	\r\nMaletín/estuche, Adaptador para conector\r\n	Modelo: 	\r\nStudio\r\nEstilo: 	\r\nOver The Ear\r\n	UPC: 	\r\n484848484992'),
(3, 'Samsung Galaxy Gear, Android Smart Watch Para S3, S4, Note 2 y 3', 'img/sg1.JPG', 129998, 'Estado: 	\r\nReacondicionado por el vendedor\r\n	Marca: 	\r\nSamsung\r\nCamera Resolution: 	\r\n1.9MP\r\n	MPN: 	\r\nSM-V700\r\nSpeaker: 	\r\nMono\r\n	Compatible Operating System: 	\r\nAndroid\r\nSensors: 	\r\nAccelerometer, Gyroscope\r\n	Processor: 	\r\n800MHz Single-Core Processor\r\nBluetooth Compliant: 	\r\n4.0\r\n	Capacidad de disco duro: 	\r\n4 GB\r\nTipo de batería: 	\r\nLiION\r\n	RAM: 	\r\n512 MB\r\nBattery Capacity: 	\r\n315 mAh\r\n	Display Size (Diagonal): 	\r\n1.63 Inches\r\nCompatibilty: 	\r\nGalaxy S III, S4, Note II, Note 3\r\n	Screen Resolution: 	\r\n320 x 320'),
(4, 'Ultra Delgada Slim Suave Tpu Transparente Clear Skin Funda Para Iphone 6 (4,7 ")', 'img/f_smartphone.JPG', 15000, '\r\n    Slim TPU (Flexible Rubber) for the New Apple iPhone 6\r\n    Fits perfectly for you iPhone 6, displays your iPhone in amazing color and detail. Covers all buttons for increased protection\r\n    See through TPU Rubber case shows off your iPhone in style with our choice of color\r\n    Protects your iPhone 6 from scratches and minor bumps by wrapping around the back and edge.\r\n    Light and durable, this slim soft cases give you the protection you need.\r\n    Precise cutouts for complete access to all buttons, cameras, speakers, and ports.\r\n    Ultra light, crystal clear, easy to put on and take off.\r\n\r\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos`
--

CREATE TABLE IF NOT EXISTS `puntos` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(255) NOT NULL,
  `id_producto` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `puntos`
--

INSERT INTO `puntos` (`id`, `id_usuario`, `id_producto`) VALUES
(1, 1, 1),
(2, 1, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(766) COLLATE utf8_bin NOT NULL,
  `contrasena` varchar(766) COLLATE utf8_bin NOT NULL,
  `correo` varchar(766) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `contrasena`, `correo`) VALUES
(1, 'Dario', '123456', 'dario@mail.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
