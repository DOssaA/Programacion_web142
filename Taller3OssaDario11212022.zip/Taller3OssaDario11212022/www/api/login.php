<?php
	include "includes/database.php";   //es lo mismo al parecer que include_once
	$user = $_POST['username'];
	$pass = $_POST['password'];

	$query = "SELECT count(*) FROM ajax.user WHERE username = '$user' AND password = '$pass'";
	$resultado = mysqli_query($cxn,$query);

	while ($row = mysqli_fetch_array($resultado)) {
		$valor = $row[0];
	}

	echo $valor;

	if($valor == 1){
		$result['error'] = false;
		$result['message'] = 'Usuario y clave correctas';
	}else{
		$result['error'] = true;
		$result['message'] = 'El usuario y clave no existen o no coinciden';
	}

	echo json_encode($result);  //convierte en un objeto que se puede ver como un string , liviano, un objeto json

?>