<?php
	include "includes/database.php";   //es lo mismo al parecer que include_once
	$result = "";
	$tmp = [];

	$query = "SELECT * FROM ajax.user WHERE 1";
	$resultado = mysqli_query($cxn,$query);

	while ($row = mysqli_fetch_array($resultado)) {
		$usuarios["id"] = $row["id"];
		$usuarios["username"] = $row["username"];

		array_push($tmp, $usuarios); //tmp arreglo de arreglos ~
	}

	$result['error'] = false;
	$result['usuarios'] = $tmp;

	echo json_encode($result);  //convierte en un objeto que se puede ver como un string , liviano, un objeto json

?>