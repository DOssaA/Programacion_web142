<?php
	include "includes/database.php";   //es lo mismo al parecer que include_once
	$result = "";
	$id_user = $_POST["id_user"];
	$tmp = [];

	$query = "SELECT * FROM ajax.posts WHERE id_user = '$id_user'";
	$resultado = mysqli_query($cxn,$query);

	while ($row = mysqli_fetch_array($resultado)) {
		$posts["id"] = $row["id"];
		$posts["title"] = $row["title"];
		$posts["content"] = $row["content"];

		array_push($tmp, $posts); //tmp arreglo de arreglos ~
	}

	$result['error'] = false;
	$result['posts'] = $tmp;

	echo json_encode($result);  //convierte en un objeto que se puede ver como un string , liviano, un objeto json

?>