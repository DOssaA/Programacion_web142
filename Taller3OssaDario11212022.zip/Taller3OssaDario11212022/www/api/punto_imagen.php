<?php
	include_once 'includes/database.php';
	$tipo = 1;  //por defecto
	if(isset($_POST['tipo'])){
		$tipo = $_POST['tipo'];
	}
	$tmp = [];
	$puntos = [];

	$query = "SELECT * FROM taller3_ossa_dario.puntos WHERE tipo = '$tipo'";
	$result = mysqli_query($cxn, $query);

	while($row = mysqli_fetch_array($result)){
		$puntos["id"] = $row["id"];
		$puntos["nombre"] = $row["nombre"];
		$puntos["latitud"] = $row["latitud"];
		$puntos["longitud"] = $row["longitud"];
		$puntos["imagen"] = $row["imagen"];

		array_push($tmp, $puntos);   //$tmp, arreglo de arreglos
	}

	$resultado['error'] = false;
	$resultado['puntos'] = $tmp;

	echo json_encode($resultado);  //convierte en un objeto que se puede ver como un string , liviano, un objeto json


?>