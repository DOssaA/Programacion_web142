		function iniciar(){

          //Canvas
          soltar = document.getElementById('lienzo');
          lienzo = soltar.getContext('2d');
        /*  lienzo.fillStyle ="#000099";
          lienzo.strokeStyle ="#990000";
          lienzo.strokeRect(100,100,120,120);
          lienzo.fillRect(110,110,100,100);
          lienzo.clearRect(120,120,80,80);
        

          //gradiente que no funciono
          var gradiente = lienzo.createLinearGradient(0,0,10,100);
          gradiente.addColorStop(0.5, '#00ffff');
          gradiente.addColorStop(1, '#000000');
          lienzo.fillStyle= gradiente;
        */

          //imagen temporal canvas
          var imagen = new Image();
          imagen.src = "img/dropzone.png";
          imagen.addEventListener("load", function(){
            lienzo.drawImage(imagen,0,0,100,100);
          },false);


          //Drag and drop

          var dragSrcEl = null;

          //imagenes origen
          var imagenes = document.querySelectorAll('#caja_imagenes img');
          for (var i = 0; i < imagenes.length; i++) {
            imagenes[i].addEventListener('dragstart',arrastrado,false);
            imagenes[i].addEventListener('dragend',finalizado,false);
          };

          function arrastrado(e){
            //var codigo = '<img src="'+origen.getAttribute('src')+'">';
            //e.dataTransfer.setData('Text',codigo);
            dragSrcEl = this;
            console.log("arrastrado: "+dragSrcEl);
            var elemento = e.target;
            e.dataTransfer.setData('Text',elemento.getAttribute('id'));
            e.dataTransfer.setDragImage(e.target, 0, 0);
          }
          function finalizado(e){
            var elemento = e.target;
            //elemento.style.visibility="hidden";
          }
          
          //lienzo
          soltar.addEventListener('dragenter', soltarEntrando ,false);
          soltar.addEventListener('dragleave', soltarSaliendo ,false);
          soltar.addEventListener('dragover', function(e){ e.preventDefault(); } ,false);
          soltar.addEventListener('drop',soltarSoltado,false);

          //*******SI SE HACE LO DE PODER DEVOLVER HABRIA QUE HACER FUNCIONES PARA EL DRAG AND DROP DEL LIENZO->dragstart, dragend,  saber ubicar la imagen tambien, habria que mirar como obtener su info!, TAMBIEN LAS QUE FALTAN PARA LAS IMAGENES -> dragenter, dragleave, dragover, drop  PARA VOLVER A PONERLA SI ES LA CORRESPONDIENTE***********************************************************************************

          function soltarEntrando(e){
            e.preventDefault();
            soltar.style.background="rgba(0,150,0,.2)";
          }

          function soltarSaliendo(e){
            e.preventDefault();
            soltar.style.background="#FFFFFF";
          }

          function soltarSoltado(e){
            e.preventDefault();
            if (dragSrcEl != this && this == document.getElementById('lienzo')) {
            	dragSrcEl.style.visibility="hidden";
            limpiarLienzo();
            soltar.style.background="#FFFFFF";
            //soltar.innerHTML=e.dataTransfer.getData('URL');

            // var ima = new Image();
            // ima.src = e.dataTransfer.getData('URL');
            // ima.addEventListener("load", function(){
            //   lienzo.drawImage(ima,110,110,100,100);
            // },false);
            var iden = e.dataTransfer.getData('Text');
            var elemento = document.getElementById(iden);

            var posx = e.pageX-soltar.offsetLeft;
            var posy = e.pageY-soltar.offsetTop;



            /******** Aqui va lo de ajax y actualizar datos de googlemaps para mostrar imagenes ***********/

            console.log(iden);
            //console.log(iden.constructor === String);

            var tp = (iden.split('_'))[1];
            console.log(tp);

            $.ajax({
              type: "POST",
              url: "api/punto_imagen.php", //direccion relativa a lo que se esta ejecutando: index.html
              data: {tipo : tp}
            }).done(function(){   //cuando se ejecuta funcion ajax
              console.log("Solicitud enviada al api");
            }).success(function(result){    //lo que devuelve el api
              console.log("Resultado: "+result);  
              //var resultParse = JSON.parse(result);
              var resultParse = eval("(function(){return " + result + ";})()");
              console.log(resultParse); 

              locations =[];
	       	  locations.length = 0;
	       	  while (locations.pop()) {}    //borrar locaciones
	       	  clearOverlays();

              for (var i = 0; i < resultParse.puntos.length; i++) {
              	var id = resultParse.puntos[i].id;
	              var nombre = resultParse.puntos[i].nombre;
	              var lat = resultParse.puntos[i].latitud;
	              var lng = resultParse.puntos[i].longitud;
	              var descr = resultParse.puntos[i].descripcion;
	              console.log(id+"  "+nombre+": "+lat+", "+lng);


	              locations.push([nombre,lat,lng,descr]);
              };

              console.log(locations);
              infowindow = new google.maps.InfoWindow();

              recargarMapa();
            
            }).error(function(error){  //si hay error lo que devuelve
              console.log("Error: "+error);  
            })
            lienzo.drawImage(elemento,posx,posy,100,100);
            /***************************************************************************************/
        	}

          }

          //Google maps
        var locations = [];

        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 11,
          center: new google.maps.LatLng(48.861213, 2.309197),
          mapTypeId: google.maps.MapTypeId.ROADMAP
        });

        recargarMapa();

        function recargarMapa(){

          infowindow = new google.maps.InfoWindow();

          var marker, i;

          for (i = 0; i < locations.length; i++) {
            marker = new google.maps.Marker({
              position: new google.maps.LatLng(locations[i][1], locations[i][2]),
              title: locations[i][0],
              map: map
            });

            google.maps.event.addListener(marker, 'click', (function(marker, i) {
              return function() {
                infowindow.setContent(locations[i][3]);
                infowindow.open(map, marker);
              }
            })(marker, i));
          }
        }

        function limpiarLienzo(){
          lienzo.clearRect(0, 0, soltar.width, soltar.height);
        }

        function clearOverlays() {
		  for (var i = 0; i < locations.length; i++ ) {
		    locations[i].setMap(null);
		  }
		  locations.length = 0;
		}

        }

        window.addEventListener("load", iniciar, false);
