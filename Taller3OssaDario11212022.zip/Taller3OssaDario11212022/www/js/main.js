		function iniciar(){

          //Canvas, referencia, libro guia html5
          soltar = document.getElementById('lienzo');
          lienzo = soltar.getContext('2d');


          //Referencia google maps : https://developers.google.com/maps/documentation/javascript/examples/marker-remove?hl=es
          var map;
          var markers = [];

          function initialize() {
            var locCentro = new google.maps.LatLng(48.861213, 2.309197);
            var mapOptions = {
              zoom: 11,
              center: locCentro,
              mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            map = new google.maps.Map(document.getElementById('map'),
                mapOptions);

            // // This event listener will call addMarker() when the map is clicked.
            // google.maps.event.addListener(map, 'click', function(event) {
            //   addMarker(event.latLng);
            // });
          }

          // Add a marker to the map and push to the array.
          function addMarker(locat, titulo) {
            var marker = new google.maps.Marker({
              position: locat,
              title: titulo,
              map: map
            });
            markers.push(marker);

            infowindow = new google.maps.InfoWindow();

            google.maps.event.addListener(marker, 'click', (function(marker, i) {
              return function() {
                infowindow.setContent(titulo);
                infowindow.open(map, marker);
              }
            })(marker, i));

          }

          // Sets the map on all markers in the array.
          function setAllMap(map) {
            for (var i = 0; i < markers.length; i++) {
              markers[i].setMap(map);
            }
          }

          // Removes the markers from the map, but keeps them in the array.
          function clearMarkers() {
            setAllMap(null);
          }

          // Shows any markers currently in the array.
          function showMarkers() {
            setAllMap(map);
          }

          // Deletes all markers in the array by removing references to them.
          function deleteMarkers() {
            clearMarkers();
            markers = [];
          }

          initialize();

          //imagen temporal canvas
          var imagen = new Image();
          imagen.src = "img/dropzone.png";
          imagen.addEventListener("load", function(){
            lienzo.drawImage(imagen,0,0,100,100);
          },false);


          //Drag and drop

          var dragSrcEl = null;

          //imagenes origen
          var imagenes = document.querySelectorAll('#caja_imagenes img');
          for (var i = 0; i < imagenes.length; i++) {
            imagenes[i].addEventListener('dragstart',arrastrado,false);
            imagenes[i].addEventListener('dragend',finalizado,false);
          };

          function arrastrado(e){
                //var codigo = '<img src="'+origen.getAttribute('src')+'">';
            //e.dataTransfer.setData('Text',codigo);
            dragSrcEl = this;
            console.log("arrastrado: "+dragSrcEl);
            var elemento = e.target;
            e.dataTransfer.setData('Text',elemento.getAttribute('id'));
            e.dataTransfer.setDragImage(e.target, 0, 0);
          }
          function finalizado(e){
            var elemento = e.target;
            //elemento.style.visibility="hidden";
          }
          
          //lienzo
          soltar.addEventListener('dragenter', soltarEntrando ,false);
          soltar.addEventListener('dragleave', soltarSaliendo ,false);
          soltar.addEventListener('dragover', function(e){ e.preventDefault(); } ,false);
          soltar.addEventListener('drop',soltarSoltado,false);

          //*******SI SE HACE LO DE PODER DEVOLVER HABRIA QUE HACER FUNCIONES PARA EL DRAG AND DROP DEL LIENZO->dragstart, dragend,  saber ubicar la imagen tambien, habria que mirar como obtener su info!, TAMBIEN LAS QUE FALTAN PARA LAS IMAGENES -> dragenter, dragleave, dragover, drop  PARA VOLVER A PONERLA SI ES LA CORRESPONDIENTE***********************************************************************************

          function soltarEntrando(e){
            e.preventDefault();
            soltar.style.background="rgba(0,150,0,.2)";
          }

          function soltarSaliendo(e){
            e.preventDefault();
            soltar.style.background="#FFFFFF";
          }

          function soltarSoltado(e){
            e.preventDefault();
            if (dragSrcEl != this && this == document.getElementById('lienzo')) {
            	dragSrcEl.style.visibility="hidden";
            limpiarLienzo();
            soltar.style.background="rgba(0,0,0,0)";
            //soltar.innerHTML=e.dataTransfer.getData('URL');

            // var ima = new Image();
            // ima.src = e.dataTransfer.getData('URL');
            // ima.addEventListener("load", function(){
            //   lienzo.drawImage(ima,110,110,100,100);
            // },false);
            var iden = e.dataTransfer.getData('Text');
            var elemento = document.getElementById(iden);

            var posx = e.pageX-soltar.offsetLeft;
            var posy = e.pageY-soltar.offsetTop;



            /******** Aqui va lo de ajax y actualizar datos de googlemaps para mostrar imagenes ***********/

            console.log(iden);
            //console.log(iden.constructor === String);

            var tp = (iden.split('_'))[1];
            console.log(tp);
            elemento.style.visibility="visible";
            //lienzo.drawImage(elemento,posx,posy,100,100);
            var imagenE = new Image();
            imagenE.src = elemento.getAttribute('src');
            imagenE.id = elemento.getAttribute('id');
            imagenE.addEventListener("load", function(){
              lienzo.drawImage(imagenE,0,0,100,100);     //NO PUEDO CREER QUE FUERA POR LA POSICIÓN!!
                 //lienzo.drawImage(imagenE,posx,posy,100,100);
            },false);

            console.log(elemento);
            console.log(imagenE);


            $.ajax({
              type: "POST",
              url: "api/punto_imagen.php", //direccion relativa a lo que se esta ejecutando: index.html
              data: {tipo : tp}
            }).done(function(){   //cuando se ejecuta funcion ajax
              console.log("Solicitud enviada al api");
            }).success(function(result){    //lo que devuelve el api

              console.log("Resultado: "+result);  
              resultParse = JSON.parse(result);
                
              //var resultParse = eval("(function(){return " + result + ";})()");
              console.log(resultParse); 
              console.log("hubo error? sasasda "+resultParse.error); 

              deleteMarkers();          
              console.log("markers "+markers.length);
              for (var i = 0; i < markers.length; i++) {
                console.log(markers[i])
              };
              markers = [];
              while (markers.pop()) {}    //borrar locaciones
              console.log("markers "+markers.length);
              for (var i = 0; i < markers.length; i++) {
                console.log(markers[i])
              };
              for (var i = 0; i < resultParse.puntos.length; i++) {
              	var id = resultParse.puntos[i].id;
	              var nombre = resultParse.puntos[i].nombre;
	              var lat = resultParse.puntos[i].latitud;
	              var lng = resultParse.puntos[i].longitud;
	              var imag = resultParse.puntos[i].imagen;
	              console.log(id+"  "+nombre+": "+lat+", "+lng+", "+imag);
               // $(".container").append( "<figure><img src='"+imag+"'/></figure>");
                var locacion = new google.maps.LatLng(lat, lng);
                console.log(locacion);
	              addMarker(locacion,nombre);
              };
            
            }).error(function(error){  //si hay error lo que devuelve
              console.log("Error: "+error);  
            })

                        /***************************************************************************************/
        	 }

          }

      function limpiarLienzo(){
        lienzo.clearRect(0, 0, soltar.width, soltar.height);
      }
    }

    window.addEventListener("load", iniciar, false);
