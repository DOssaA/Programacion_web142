-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-11-2014 a las 07:22:04
-- Versión del servidor: 5.6.16
-- Versión de PHP: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `taller3_ossa_dario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos`
--

CREATE TABLE IF NOT EXISTS `puntos` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tipo` int(5) NOT NULL COMMENT '0 sitio turistico, 1 rest o hotel, 2 transporte',
  `nombre` varchar(766) COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `latitud` float NOT NULL,
  `longitud` float NOT NULL,
  `imagen` varchar(766) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10 ;

--
-- Volcado de datos para la tabla `puntos`
--

INSERT INTO `puntos` (`id`, `tipo`, `nombre`, `descripcion`, `latitud`, `longitud`, `imagen`) VALUES
(1, 1, 'Louvre Museum', 'Louvre Museum is one of the world''s largest museums and a historic monument.Nearly 35,000 objects from prehistory to the 21st century are exhibited over an area of 60,600 square metres (652,300 square feet). The Louvre is the world''s most visited museum, and received more than 9.7 million visitors in 2012', 48.8603, 2.33863, 'img/Louvre.jpg'),
(2, 1, 'Eiffel Tower', 'The Eiffel Tower (French: La tour Eiffel) is an iron lattice tower located on the Champ de Mars in Paris. It was named after the engineer Gustave Eiffel, whose company designed and built the tower. Erected in 1889 as the entrance arch to the 1889 World''s Fair, it was initially criticised by some of France''s leading artists and intellectuals for its design, but has become both a global cultural icon of France and one of the most recognizable structures in the world. The tower is the tallest structure in Paris and the most-visited paid monument in the world; 6.98 million people ascended it in 2011. The tower received its 250 millionth visitor in 2010', 48.8589, 2.29449, 'img/eiffel.jpg'),
(3, 1, 'The Arc de Triomphe', 'The Arc de Triomphe de l''Étoile (French pronunciation: ​[aʀk də tʀiɔ̃f də letwal], Arch of Triumph of the Star) is one of the most famous monuments in Paris. It stands in the centre of the Place Charles de Gaulle (originally named Place de l''Étoile), at the western end of the Champs-Élysées. It should not be confused with a smaller arch, the Arc de Triomphe du Carrousel, which stands west of the Louvre. The Arc de Triomphe (in English: "Triumphal Arch") honours those who fought and died for France in the French Revolutionary and the Napoleonic Wars, with the names of all French victories and generals inscribed on its inner and outer surfaces. Beneath its vault lies the Tomb of the Unknown Soldier from World War I.', 48.8739, 2.2949, 'img/arco_triunfo.jpg'),
(4, 2, 'Spring restaurant', 'Ever since Chicago-born chef Daniel Rose moved from the 9th arrondissement to a renovated 17th-century house in Les Halles in July 2010, he''s been playing to a packed house with his inventive cuisine du marche menu. This talented American shows off just how cosmopolitan the city''s culinary talent pool has become, and Parisians have been swooning over dishes such as Basque country trout with avocado and coriander flowers and grilled New Caledonian prawns on a bed of shaved baby fennel. There''s also Buvette (wine bar) in the basement, with a selection of charcuterie, cheese and several plats du jour; and with reservations tough to land for a table upstairs, it''s a good bet for anyone who wants to taste Rose''s wares without going through the reservation wringer. ', 48.861, 2.34207, 'img/spring.jpg'),
(5, 2, 'Ze Kitchen Galerie Restaurant', 'Styled like the neighbouring art galleries on this Saint Germain des Pres side street, this loft-like white space with parquet floors is furnished with steel tables and chairs and decorated with contemporary art. Chef William Ledeuil''s popular restaurant offers an intriguing experience of contemporary French cooking. Ledeuil, who trained with Guy Savoy, is fascinated by Asia and makes imaginative use of oriental herbs and ingredients in original dishes like Sardinian malloreddus pasta with a pesto of Thai herbs, parmesan cream and green olive condiment, or grilled monkfish with an aubergine marmelade and Thai-seasoned sauce vierge. ', 48.855, 2.34122, 'img/zekitchen.jpg'),
(6, 2, 'Four Seasons Hotel George V Paris', 'A stay in this magnificent oasis near the Champs-Élysées is a unique experience that is accented by the excellent food at Le Cinq, the hotel''s flagship restaurant. This is a temple of classic French cuisine. The gourmet tasting menu offers six courses, and on it can be found a remarkable lobster tart with French bean salad, spiced sea bass with balsamic vinegar, milk-fed veal chop in its own juice with crispy risotto cake, citrus and tomato emulsion, strawberry sorbet to finish with warm coffee, and chocolate millefeuille.\r\nDesserts are out-of-this world, including compote of citrus fruit steeped in Earl Grey tea with a puffed rice Florentine wafer and ten-hour baked apples with caramel ice cream and caramel cider. Le Cinq and the superbly stocked wine cave are directed by Eric Beaumard, who earned the title of best sommelier in France and became vice champion of the world. The service is impeccable.\r\n', 48.8688, 2.30049, 'img/fourseasons.jpg'),
(7, 3, 'Paris-Le Bourget Airport', 'Paris-Le Bourget Airport is an airport located within portions of the communes of Le Bourget, Bonneuil-en-France, Dugny and Gonesse, 6 NM (11 km; 6.9 mi) north-northeast[2] (NNE) of Paris, France. It is now used only for general aviation (business aviation) and air shows, most notably the Paris Air Show.', 48.9619, 2.43808, 'img/lebourget.jpg'),
(8, 3, 'Paris Charles de Gaulle Airport', 'Paris Charles de Gaulle Airport (CDG) is one of the busiest passenger airports in Europe and is the larger of Paris'' two airports...\r\n\r\nCharles de Gaulle Airport is 14 miles (23 kilometers) northeast of Paris and has extensive road and rail links to the capital city and beyond. Getting to Paris from Charles de Gaulle is easy with RATP buses, taxis and limousines all operating from Paris CDG.\r\n\r\nMajor domestic and international tourist destinations are easily accessible by TGV at Paris Charles de Gaulle, and it was one of the first airports to have a rail service connecting to it. From CDG Airport, it takes about 45 minutes to get to the centre of Paris, 10 minutes to Disney World and an hour to Brussels and Lille.', 49.008, 2.56011, 'img/charles.jpg'),
(9, 3, 'Orly Sud Airport', 'Paris Orly Airport (French: Aéroport de Paris-Orly) (IATA: ORY, ICAO: LFPO) is an international airport located partially in Orly and partially in Villeneuve-le-Roi, 7 NM (13 km; 8.1 mi) south of Paris, France. It has flights to cities in Europe, the Middle East, Africa, the Caribbean, North America and Southeast Asia.\r\n\r\nPrior to the construction of Charles de Gaulle Airport, Orly was the main airport of Paris. Even with the shift of most international traffic to Charles de Gaulle Airport, Orly remains the busiest French airport for domestic traffic and the second busiest French airport overall in terms of passenger traffic, with 27,139,076 in 2011', 48.7279, 2.36849, 'img/orly.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
